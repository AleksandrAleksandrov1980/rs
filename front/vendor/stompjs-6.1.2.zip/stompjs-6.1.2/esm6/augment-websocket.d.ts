import { IStompSocket } from './types';
/**
 * @internal
 */
export declare function augmentWebsocket(webSocket: IStompSocket, debug: (msg: string) => void): void;
