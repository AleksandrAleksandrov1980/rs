/**
 * Call [Client#subscribe]{@link Client#subscribe} to create a StompSubscription.
 *
 * Part of `@stomp/stompjs`.
 */
export class StompSubscription {
}
//# sourceMappingURL=stomp-subscription.js.map